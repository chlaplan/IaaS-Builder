﻿configuration Configuration
{
   param
   (
	[Int]$RetryCount = 20,
	[Int]$RetryIntervalSec = 120,
        [Parameter(Mandatory)] [String]$DomainName,
        [Parameter(Mandatory)] [string]$FedServiceDisplayName,
        [Parameter(Mandatory)] [string]$FedServiceName,
        [Parameter(Mandatory)] [string]$AdfsSrvActName,
	[Parameter(Mandatory)] [string]$DCNameFQDN,
        [Parameter(Mandatory)] [String]$STIG,
        [Parameter(Mandatory)] [String]$MSFTBaseline,
        [Parameter(Mandatory)] [String]$SQLName,
        [Parameter(Mandatory)] [String]$SQLAlias,
        [Parameter(Mandatory)] [String]$DCName,
        [Parameter(Mandatory)] [String]$DPMPName,
        [Parameter(Mandatory)] [String]$PSName,
        [Parameter(Mandatory)] [String]$DNSIPAddress,
        [Parameter(Mandatory)] [String]$SharePointVersion,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$Admincreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SqlSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSetupCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPFarmCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPAppPoolCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPPassphraseCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperUserCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperReaderCreds
    )

    Import-DscResource -ModuleName TemplateHelpDSC,ComputerManagementDsc,ActiveDirectoryDsc,ActiveDirectoryCSDsc,CertificateDsc,xPSDesiredStateConfiguration

    $LogFolder = "TempLog"
    $LogPath = "c:\$LogFolder"
    $DName = $DomainName.Split(".")[0]
    $PSComputerAccount = "$DName\$PSName$"
    $DPMPComputerAccount = "$DName\$DPMPName$"
    $StartTime = [datetime]::Now.AddMinutes(15)
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    # Task Scheduler resolves a principal with LookupAccountName, which expects the NetBIOS
    # domain name. The FQDN form "lab.local\labadmin" fails there with "No mapping between
    # account names and security IDs was done", so the scheduled tasks below use this one.
    [System.Management.Automation.PSCredential]$TaskCreds = New-Object System.Management.Automation.PSCredential ("$DName\$($Admincreds.UserName)", $Admincreds.Password)

    Node LOCALHOST
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        SetCustomPagingFile PagingSettings
        {
            Drive       = 'C:'
            InitialSize = '8192'
            MaximumSize = '8192'
        }
        
        InstallFeatureForSCCM InstallFeature
        {
            Name = 'DC'
            Role = 'DC'
            DependsOn = "[SetCustomPagingFile]PagingSettings"
        }

        SetupDomain FirstDS
        {
            DomainFullName = $DomainName
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = "[InstallFeatureForSCCM]InstallFeature"
        }

        InstallCA InstallCA
        {
            HashAlgorithm = "SHA256"
            DependsOn = "[SetupDomain]FirstDS"
        }

        #**********************************************************
        # Configure Security GPOs
        #**********************************************************
        # These only ever did anything when the matching switch was on - the scripts
        # themselves start with an "if enabled" test - but the tasks were registered
        # either way, so an unhardened lab still failed here for no benefit.
        if ($STIG -eq 'true')
        {
            ScheduledTask STIGImport
            {
                TaskName            = 'STIGImport'
                TaskPath            = '\MyTasks'
                ActionExecutable    = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
                ActionArguments     = "-WindowStyle Hidden -NonInteractive -Executionpolicy unrestricted -file .\DSCWork\Configuration.0\STIGDC.ps1 $STIG"
                ScheduleType        = 'Once'
                RandomDelay         = '00:05:00'
                StartTime           = $StartTime
                StartWhenAvailable  = $true
                ActionWorkingPath   = (Get-Location).Path
                Enable              = $true
                ExecuteAsCredential = $TaskCreds
                RunLevel            = 'Highest'
                # Registering this task needs the domain to exist so the principal above can
                # be resolved to a SID. Without this the LCM attempts it on a workgroup
                # machine, before the forest is created, and the whole run fails.
                DependsOn           = "[InstallCA]InstallCA"
            }
        }

        if ($MSFTBaseline -eq 'true')
        {
            ScheduledTask MSFTBaseline
            {
                TaskName            = 'MSFTBaseline'
                TaskPath            = '\MyTasks'
                ActionExecutable    = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
                ActionArguments     = "-WindowStyle Hidden -NonInteractive -Executionpolicy unrestricted -file .\DSCWork\Configuration.0\MSFTBaseline.ps1 $MSFTBaseline"
                ScheduleType        = 'Once'
                RandomDelay         = '00:05:00'
                StartTime           = $StartTime
                StartWhenAvailable  = $true
                ActionWorkingPath   = (Get-Location).Path
                Enable              = $true
                ExecuteAsCredential = $TaskCreds
                RunLevel            = 'Highest'
                # Registering this task needs the domain to exist so the principal above can
                # be resolved to a SID. Without this the LCM attempts it on a workgroup
                # machine, before the forest is created, and the whole run fails.
                DependsOn           = "[InstallCA]InstallCA"
            }
        }
    }
}
