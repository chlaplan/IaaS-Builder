﻿configuration Configuration
{
   param
   (
	[Int]$RetryCount = 20,
	[Int]$RetryIntervalSec = 120,
        [Parameter(Mandatory)] [String]$DomainName,
        [Parameter(Mandatory)] [string]$FedServiceDisplayName,
        [Parameter(Mandatory)] [string]$FedServiceName,
        [Parameter(Mandatory)] [string]$AdfsSrvActName,
	[Parameter(Mandatory)] [string]$DCNameFQDN,
        [Parameter(Mandatory)] [String]$STIG,
        [Parameter(Mandatory)] [String]$MSFTBaseline,
        # Not Mandatory, and defaults to off: an older template that does not pass this
        # should build a lab without a certificate authority, not fail outright.
        [String]$InstallCA = 'false',
        # Not Mandatory: a plan or template written before install media could be redirected must
        # still deploy, taking every installer from the public internet exactly as it always has.
        [String]$InstallMediaLocation = '',
        [String]$InstallMediaFallback = 'false',
        [Parameter(Mandatory)] [String]$SQLName,
        [Parameter(Mandatory)] [String]$SQLAlias,
        [Parameter(Mandatory)] [String]$DCName,
        [Parameter(Mandatory)] [String]$DPMPName,
        [Parameter(Mandatory)] [String]$PSName,
        [Parameter(Mandatory)] [String]$DNSIPAddress,
        [Parameter(Mandatory)] [String]$SharePointVersion,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$Admincreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SqlSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSetupCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPFarmCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPAppPoolCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPPassphraseCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperUserCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperReaderCreds
    )

    Import-DscResource -ModuleName TemplateHelpDSC,ComputerManagementDsc,ActiveDirectoryDsc,ActiveDirectoryCSDsc,CertificateDsc,xPSDesiredStateConfiguration

    $LogFolder = "TempLog"
    $LogPath = "c:\$LogFolder"
    $DName = $DomainName.Split(".")[0]
    $PSComputerAccount = "$DName\$PSName$"
    $DPMPComputerAccount = "$DName\$DPMPName$"
    $StartTime = [datetime]::Now.AddMinutes(15)
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    # Task Scheduler resolves a principal with LookupAccountName, which expects the NetBIOS
    # domain name. The FQDN form "lab.local\labadmin" fails there with "No mapping between
    # account names and security IDs was done", so the scheduled tasks below use this one.
    [System.Management.Automation.PSCredential]$TaskCreds = New-Object System.Management.Automation.PSCredential ("$DName\$($Admincreds.UserName)", $Admincreds.Password)

    Node LOCALHOST
    {
        # Tells every installer script on this machine where to get its media. Written even when
        # no location was given, so the scripts can always read one answer from one place rather
        # than each inventing its own default.
        File InstallMediaSetting
        {
            DestinationPath = 'C:\InstallMedia.txt'
            Contents        = "Location=$InstallMediaLocation`r`nFallback=$InstallMediaFallback`r`n"
            Type            = 'File'
            Ensure          = 'Present'
        }

        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        SetCustomPagingFile PagingSettings
        {
            Drive       = 'C:'
            InitialSize = '8192'
            MaximumSize = '8192'
        }
        
        InstallFeatureForSCCM InstallFeature
        {
            Name = 'DC'
            Role = 'DC'
            DependsOn = "[SetCustomPagingFile]PagingSettings"
        }

        SetupDomain FirstDS
        {
            DomainFullName = $DomainName
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = "[InstallFeatureForSCCM]InstallFeature"
        }

        # An enterprise root CA on the domain controller is convenient for a lab but is not
        # something you would do in production, and some labs want the CA on its own server
        # instead - that is the CA role, which runs CAConfiguration.ps1.
        if ($InstallCA -eq 'true')
        {
            InstallCA InstallCA
            {
                HashAlgorithm = "SHA256"
                DependsOn = "[SetupDomain]FirstDS"
            }
        }

        #**********************************************************
        # Configure Security GPOs
        #**********************************************************
        # These only ever did anything when the matching switch was on - the scripts
        # themselves start with an "if enabled" test - but the tasks were registered
        # either way, so an unhardened lab still failed here for no benefit.
        if ($STIG -eq 'true')
        {
            ScheduledTask STIGImport
            {
                TaskName            = 'STIGImport'
                TaskPath            = '\MyTasks'
                ActionExecutable    = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
                ActionArguments     = "-WindowStyle Hidden -NonInteractive -Executionpolicy unrestricted -file .\DSCWork\Configuration.0\STIGDC.ps1 $STIG"
                ScheduleType        = 'Once'
                RandomDelay         = '00:05:00'
                StartTime           = $StartTime
                StartWhenAvailable  = $true
                ActionWorkingPath   = (Get-Location).Path
                Enable              = $true
                ExecuteAsCredential = $TaskCreds
                RunLevel            = 'Highest'
                # Registering this task needs the domain to exist so the principal above can
                # be resolved to a SID. Without this the LCM attempts it on a workgroup
                # machine, before the forest is created, and the whole run fails.
                DependsOn           = "[SetupDomain]FirstDS"
            }
        }

        if ($MSFTBaseline -eq 'true')
        {
            ScheduledTask MSFTBaseline
            {
                TaskName            = 'MSFTBaseline'
                TaskPath            = '\MyTasks'
                ActionExecutable    = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
                ActionArguments     = "-WindowStyle Hidden -NonInteractive -Executionpolicy unrestricted -file .\DSCWork\Configuration.0\MSFTBaseline.ps1 $MSFTBaseline"
                ScheduleType        = 'Once'
                RandomDelay         = '00:05:00'
                StartTime           = $StartTime
                StartWhenAvailable  = $true
                ActionWorkingPath   = (Get-Location).Path
                Enable              = $true
                ExecuteAsCredential = $TaskCreds
                RunLevel            = 'Highest'
                # Registering this task needs the domain to exist so the principal above can
                # be resolved to a SID. Without this the LCM attempts it on a workgroup
                # machine, before the forest is created, and the whole run fails.
                DependsOn           = "[SetupDomain]FirstDS"
            }
        }
    }
}
