﻿configuration Configuration
{
   param
   (
	[Int]$RetryCount = 20,
	[Int]$RetryIntervalSec = 120,
        [Parameter(Mandatory)] [String]$DomainName,
        [Parameter(Mandatory)] [string]$FedServiceDisplayName,
        [Parameter(Mandatory)] [string]$FedServiceName,
        [Parameter(Mandatory)] [string]$AdfsSrvActName,
	[Parameter(Mandatory)] [string]$DCNameFQDN,
        [Parameter(Mandatory)] [String]$STIG,
        [Parameter(Mandatory)] [String]$MSFTBaseline,
        [Parameter(Mandatory)] [String]$SQLName,
        [Parameter(Mandatory)] [String]$SQLAlias,
        [Parameter(Mandatory)] [String]$DCName,
        [Parameter(Mandatory)] [String]$DPMPName,
        [Parameter(Mandatory)] [String]$PSName,
        [Parameter(Mandatory)] [String]$DNSIPAddress,
        [Parameter(Mandatory)] [String]$SharePointVersion,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$Admincreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SqlSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSetupCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPFarmCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPAppPoolCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPPassphraseCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperUserCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperReaderCreds
    )

    Import-DscResource -ModuleName TemplateHelpDSC,ComputerManagementDsc,ActiveDirectoryDsc,ActiveDirectoryCSDsc,CertificateDsc,xPSDesiredStateConfiguration

    $LogFolder = "TempLog"
    $LogPath = "c:\$LogFolder"
    $DName = $DomainName.Split(".")[0]
    $PSComputerAccount = "$DName\$PSName$"
    $DPMPComputerAccount = "$DName\$DPMPName$"
    $StartTime = [datetime]::Now.AddMinutes(15)
    [String] $DomainNetbiosName = $DomainName.Split(".")[0]
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node LOCALHOST
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        SetCustomPagingFile PagingSettings
        {
            Drive       = 'C:'
            InitialSize = '8192'
            MaximumSize = '8192'
        }
   
        WindowsFeature 'ADDS'
        {
            Name   = 'AD-Domain-Services'
            Ensure = 'Present'
        }

        WindowsFeature 'RSAT-AD'
        {
            Name   = 'RSAT-AD-Tools'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }

        WindowsFeature 'RSAT-CS'
        {
            Name   = 'RSAT-AD-Tools'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }

        ADDomain Domain
        {
            DomainName                    = $DomainName
            Credential                    = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            #ForestMode                    = 'WinThreshold'
        }

        #**********************************************************
        # Configure AD CS
        #**********************************************************
       
        WindowsFeature AddADCSFeature 
        { 
            Name      = 'ADCS-Cert-Authority'
            Ensure    = 'Present'
            DependsOn = '[ADDomain]Domain'
        }
        
        ADCSCertificationAuthority CreateADCSAuthority
        {
            IsSingleInstance  = 'Yes'
            Ensure            = 'Present'
            CAType            = 'EnterpriseRootCA'
            HashAlgorithmName = 'SHA256'
            Credential        =  $DomainCreds
            DependsOn         = '[WindowsFeature]AddADCSFeature'
        }

        xScript ForceCAInstall
        {
            SetScript =
            {
                Install-AdcsCertificationAuthority -Force
            }
            GetScript            = { }
            TestScript           = { return $false } # If the TestScript returns $false, DSC executes the SetScript to bring the node back to the desired state
            DependsOn            = "[WindowsFeature]AddADCSFeature"
            PsDscRunAsCredential = $DomainCreds
        }


        #**********************************************************
        # Configure Security GPOs
        #**********************************************************
        ScheduledTask STIGImport
        {
            TaskName            = 'STIGImport'
            TaskPath            = '\MyTasks'
            ActionExecutable    = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
            ActionArguments     = "-WindowStyle Hidden -NonInteractive -Executionpolicy unrestricted -file .\DSCWork\Configuration.0\STIGDC.ps1 $STIG"
            ScheduleType        = 'Once'
            RandomDelay         = '00:05:00'
            StartTime           = $StartTime
            StartWhenAvailable  = $true
            ActionWorkingPath   = (Get-Location).Path
            Enable              = $true
            ExecuteAsCredential = $DomainCreds
            RunLevel            = 'Highest'
        }
        ScheduledTask MSFTBaseline
        {
            TaskName            = 'MSFTBaseline'
            TaskPath            = '\MyTasks'
            ActionExecutable    = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
            ActionArguments     = "-WindowStyle Hidden -NonInteractive -Executionpolicy unrestricted -file .\DSCWork\Configuration.0\MSFTBaseline.ps1 $MSFTBaseline"
            ScheduleType        = 'Once'
            RandomDelay         = '00:05:00'
            StartTime           = $StartTime
            StartWhenAvailable  = $true
            ActionWorkingPath   = (Get-Location).Path
            Enable              = $true
            ExecuteAsCredential = $DomainCreds
            RunLevel            = 'Highest'
        } 
    }
}