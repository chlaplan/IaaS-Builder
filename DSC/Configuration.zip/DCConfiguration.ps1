﻿configuration Configuration
{
   param
   (
	[Int]$RetryCount = 20,
	[Int]$RetryIntervalSec = 120,
        [Parameter(Mandatory)] [String]$DomainName,
        [Parameter(Mandatory)] [string]$FedServiceDisplayName,
        [Parameter(Mandatory)] [string]$FedServiceName,
        [Parameter(Mandatory)] [string]$AdfsSrvActName,
	[Parameter(Mandatory)] [string]$DCNameFQDN,
        [Parameter(Mandatory)] [String]$STIG,
        [Parameter(Mandatory)] [String]$MSFTBaseline,
        [Parameter(Mandatory)] [String]$SQLName,
        [Parameter(Mandatory)] [String]$SQLAlias,
        [Parameter(Mandatory)] [String]$DCName,
        [Parameter(Mandatory)] [String]$DPMPName,
        [Parameter(Mandatory)] [String]$PSName,
        [Parameter(Mandatory)] [String]$DNSIPAddress,
        [Parameter(Mandatory)] [String]$SharePointVersion,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$Admincreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SqlSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSetupCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPFarmCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPAppPoolCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPPassphraseCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperUserCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperReaderCreds
    )

    Import-DscResource -ModuleName TemplateHelpDSC,ComputerManagementDsc,ActiveDirectoryDsc,ActiveDirectoryCSDsc,CertificateDsc,xPSDesiredStateConfiguration

    $LogFolder = "TempLog"
    $LogPath = "c:\$LogFolder"
    $DName = $DomainName.Split(".")[0]
    $PSComputerAccount = "$DName\$PSName$"
    $DPMPComputerAccount = "$DName\$DPMPName$"
    $StartTime = [datetime]::Now.AddMinutes(15)
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node LOCALHOST
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        SetCustomPagingFile PagingSettings
        {
            Drive       = 'C:'
            InitialSize = '8192'
            MaximumSize = '8192'
        }
        
        InstallFeatureForSCCM InstallFeature
        {
            Name = 'DC'
            Role = 'DC'
            DependsOn = "[SetCustomPagingFile]PagingSettings"
        }

        SetupDomain FirstDS
        {
            DomainFullName = $DomainName
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn = "[InstallFeatureForSCCM]InstallFeature"
        }

        InstallCA InstallCA
        {
            HashAlgorithm = "SHA256"
            DependsOn = "[SetupDomain]FirstDS"
        }

        #**********************************************************
        # Configure Security GPOs
        #**********************************************************
        ScheduledTask STIGImport
        {
            TaskName            = 'STIGImport'
            TaskPath            = '\MyTasks'
            ActionExecutable    = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
            ActionArguments     = "-WindowStyle Hidden -NonInteractive -Executionpolicy unrestricted -file .\DSCWork\Configuration.0\STIGDC.ps1 $STIG"
            ScheduleType        = 'Once'
            RandomDelay         = '00:05:00'
            StartTime           = $StartTime
            StartWhenAvailable  = $true
            ActionWorkingPath   = (Get-Location).Path
            Enable              = $true
            ExecuteAsCredential = $DomainCreds
            RunLevel            = 'Highest'
        }
        
        ScheduledTask MSFTBaseline
        {
            TaskName            = 'MSFTBaseline'
            TaskPath            = '\MyTasks'
            ActionExecutable    = 'C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe'
            ActionArguments     = "-WindowStyle Hidden -NonInteractive -Executionpolicy unrestricted -file .\DSCWork\Configuration.0\MSFTBaseline.ps1 $MSFTBaseline"
            ScheduleType        = 'Once'
            RandomDelay         = '00:05:00'
            StartTime           = $StartTime
            StartWhenAvailable  = $true
            ActionWorkingPath   = (Get-Location).Path
            Enable              = $true
            ExecuteAsCredential = $DomainCreds
            RunLevel            = 'Highest'
        }
    }
}