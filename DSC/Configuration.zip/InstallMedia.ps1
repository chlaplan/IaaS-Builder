﻿<#
	Resolves where installer media comes from.

	Every role that needs third-party media - Configuration Manager, the Windows ADK, Exchange, the
	DISA STIG GPOs and the Microsoft security baseline - used to download it from a hard-coded
	address on the public internet. That is unreachable in a disconnected enclave, and the failure
	is invisible: the download happens inside the VM long after ARM has reported the deployment as
	succeeded, so the symptom is a machine that builds and then silently never finishes configuring.

	A deployment can now name a single location holding all of that media. It may be an internal
	web server, a UNC share or a local path on a disk attached to the VM. The file names below are
	fixed, so staging the location is just a matter of putting files with those names in it.

	This file is dot-sourced by the scripts that run from Task Scheduler. TemplateHelpDSC.psm1
	carries its own copy of these functions because it is installed to the PowerShell module path
	rather than next to this file, so it cannot dot-source it. DscInstallMediaTests asserts the two
	copies stay in step.
#>

$script:InstallMediaSettingPath = 'C:\InstallMedia.txt'

function Get-InstallMediaSetting
{
	<#
		Reads the setting the DSC configuration wrote from the installMediaLocation template
		parameter. No file means nobody asked for a mirror, which is the ordinary connected case,
		so this returns an empty location rather than failing.
	#>
	$setting = @{ Location = ''; Fallback = $false }

	if(!(Test-Path $script:InstallMediaSettingPath))
	{
		return $setting
	}

	foreach($line in (Get-Content -Path $script:InstallMediaSettingPath))
	{
		# Split on the first '=' only. A location can legitimately contain more of them - a query
		# string or a SAS token does - and those belong to the value.
		$pair = $line -split '=', 2
		if($pair.Count -ne 2)
		{
			continue
		}

		switch($pair[0].Trim())
		{
			'Location' { $setting.Location = $pair[1].Trim() }
			'Fallback' { $setting.Fallback  = ($pair[1].Trim() -eq 'true') }
		}
	}

	return $setting
}

function Get-InstallMediaUri
{
	<#
		Joins a file name onto the configured location, or returns $null when no location is set.
		Web locations take a forward slash and everything else - UNC and local paths alike - takes
		a backslash.
	#>
	param([Parameter(Mandatory)][string]$FileName)

	$setting = Get-InstallMediaSetting
	if([string]::IsNullOrWhiteSpace($setting.Location))
	{
		return $null
	}

	$base = $setting.Location.TrimEnd('/', '\')

	if($base -match '^https?://')
	{
		return "$base/$FileName"
	}

	return "$base\$FileName"
}

function Save-InstallMedia
{
	<#
		Puts a named file on disk, preferring the configured location and falling back to the
		public address the package has always used.

		When a location is configured but the file is not there, this throws by default rather than
		quietly downloading from the internet. Somebody who named an internal location has usually
		done so because the internet is not reachable, and in that case a silent fall-back turns a
		clear "stage this file" message into an hour-long hang that says nothing about media at all.
		Setting Fallback allows the other behaviour, for a connected network where the location is
		only a partial mirror of the larger files.
	#>
	param(
		[Parameter(Mandatory)][string]$FileName,
		[Parameter(Mandatory)][string]$DefaultUri,
		[Parameter(Mandatory)][string]$Destination
	)

	$setting = Get-InstallMediaSetting
	$mirror  = Get-InstallMediaUri -FileName $FileName

	if($null -ne $mirror)
	{
		if($mirror -match '^https?://')
		{
			try
			{
				Invoke-WebRequest -Uri $mirror -OutFile $Destination -UseBasicParsing
				return $mirror
			}
			catch
			{
				$reason = $_.Exception.Message
			}
		}
		elseif(Test-Path -Path $mirror)
		{
			Copy-Item -Path $mirror -Destination $Destination -Force
			return $mirror
		}
		else
		{
			$reason = 'the file is not there'
		}

		if(!$setting.Fallback)
		{
			throw ("Could not get '$FileName' from '$mirror' - $reason. This deployment was told " +
				   "to take installer media from '$($setting.Location)', so it will not download " +
				   "from the internet instead. Put a file named exactly '$FileName' in that " +
				   "location, or allow the fall-back to Microsoft if this network can reach it.")
		}
	}

	Invoke-WebRequest -Uri $DefaultUri -OutFile $Destination -UseBasicParsing
	return $DefaultUri
}
