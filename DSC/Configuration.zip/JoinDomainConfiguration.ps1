﻿configuration Configuration
{
   param
   (
	[Int]$RetryCount = 20,
	[Int]$RetryIntervalSec = 120,
        [Parameter(Mandatory)] [String]$DomainName,
        [Parameter(Mandatory)] [string]$FedServiceDisplayName,
        [Parameter(Mandatory)] [string]$FedServiceName,
        [Parameter(Mandatory)] [string]$AdfsSrvActName,
	[Parameter(Mandatory)] [string]$DCNameFQDN,
        [Parameter(Mandatory)] [String]$STIG,
        [Parameter(Mandatory)] [String]$MSFTBaseline,
        [Parameter(Mandatory)] [String]$SQLName,
        [Parameter(Mandatory)] [String]$SQLAlias,
        [Parameter(Mandatory)] [String]$DCName,
        [Parameter(Mandatory)] [String]$DPMPName,
        [Parameter(Mandatory)] [String]$PSName,
        [Parameter(Mandatory)] [String]$DNSIPAddress,
        [Parameter(Mandatory)] [String]$SharePointVersion,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$Admincreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SqlSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSetupCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPFarmCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPAppPoolCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPPassphraseCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperUserCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperReaderCreds
    )
    Set-ExecutionPolicy -ExecutionPolicy Bypass -Force
    Import-DscResource -ModuleName TemplateHelpDSC,xActiveDirectory,ActiveDirectoryDsc

    $LogFolder = "TempLog"
    $LogPath = "c:\$LogFolder"
    $DName = $DomainName.Split(".")[0]
    $DCComputerAccount = "$DName\$DCName$"

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {

        SetCustomPagingFile PagingSettings
        {
            Drive       = 'C:'
            InitialSize = '8192'
            MaximumSize = '8192'
        }

        SetDNS DnsServerAddress
        {
            DNSIPAddress = $DNSIPAddress
            Ensure = "Present"
            DependsOn = "[SetCustomPagingFile]PagingSettings"
        }

        WaitForADDomain WaitForDomain
        {
            DomainName  = $DomainName
            WaitTimeout = 900
        }

        JoinDomain JoinDomain
        {
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[WaitForADDomain]WaitForDomain"
        }

    }
}