﻿Param($MSFT)

If($MSFT -eq $True){
. "$PSScriptRoot\InstallMedia.ps1"
Import-Module .\wmifilter.psm1

$ADMXFOLDER = "C:\Windows\SYSVOL\domain\Policies\PolicyDefinitions"
$ADMLFOLDER = "C:\Windows\SYSVOL\domain\Policies\PolicyDefinitions\en-US"

$baselineUri = "https://download.microsoft.com/download/8/5/C/85C25433-A1B0-4FFA-9429-7E023E7DA8D8/Windows%2010%20Version%202004%20and%20Windows%20Server%20Version%202004%20Security%20Baseline.zip"
Save-InstallMedia -FileName "MSFTBaseline.zip" -DefaultUri $baselineUri -Destination "MSFTBaseline.zip" | Out-Null

Expand-Archive -Path .\MSFTBaseline.zip -DestinationPath C:\Packages\MSFTBaseline\ -Force

$GPOPath = Get-ChildItem -Path C:\Packages\MSFTBaseline\* -Directory -Recurse -Include '{*}'

$BaselineFiles = Get-ChildItem -Path C:\Packages\MSFTBaseline\ -Recurse
$ADMX = $BaselineFiles | Where -Property Name -like "*.admx"
$ADML = $BaselineFiles | Where -Property Name -like "*.adml"

New-Item -Path "C:\Windows\SYSVOL\domain\Policies" -Name "PolicyDefinitions" -ItemType Directory -Force
New-Item -Path "C:\Windows\SYSVOL\domain\Policies\PolicyDefinitions" -Name "en-US" -ItemType Directory -Force

foreach ($ADMXS in $ADMX){
Copy-Item -Path $ADMXS.FullName -Destination $ADMXFOLDER -Force
}

foreach ($ADMLS in $ADML){
Copy-Item -Path $ADMLS.FullName -Destination $ADMLFOLDER -Force
}

foreach ($GPOPaths in $GPOPath){
[xml]$xml = Get-Content -Path $($GPOPaths.FullName + '\bkupinfo.xml')
Import-GPO -Path $GPOPaths.parent.FullName -CreateIfNeeded -BackupId $xml.BackupInst.ID.'#cdata-section' -TargetName $xml.BackupInst.GPODisplayName.'#cdata-section'
}

New-ADOrganizationalUnit -Name "Servers"
New-ADOrganizationalUnit -Name "Workstations"

New-GPWmiFilter -Name "Windows Server 2019 Member Server" -Expression 'SELECT Version,ProductType FROM Win32_OperatingSystem WHERE Version LIKE \"10.0.17763\" AND ProductType = \"3\"'
New-GPWmiFilter -Name "Windows Server 2019 Domain Controller" -Expression 'SELECT Version,ProductType FROM Win32_OperatingSystem WHERE Version LIKE \"10.0.17763\" AND ProductType = \"2\"'
New-GPWmiFilter -Name "Windows Server 2016 Member Server" -Expression 'SELECT Version,ProductType FROM Win32_OperatingSystem WHERE Version LIKE \"10.0.14393\" AND ProductType = \"3\"'
New-GPWmiFilter -Name "Windows Server 2016 Domain Controller" -Expression 'SELECT Version,ProductType FROM Win32_OperatingSystem WHERE Version LIKE \"10.0.14393\" AND ProductType = \"2\"'

}
