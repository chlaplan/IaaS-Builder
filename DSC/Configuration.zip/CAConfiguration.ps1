﻿configuration Configuration
{
   param
   (
	[Int]$RetryCount = 20,
	[Int]$RetryIntervalSec = 120,
		[Parameter(Mandatory)] [String]$DomainName,
		[Parameter(Mandatory)] [string]$FedServiceDisplayName,
		[Parameter(Mandatory)] [string]$FedServiceName,
		[Parameter(Mandatory)] [string]$AdfsSrvActName,
	[Parameter(Mandatory)] [string]$DCNameFQDN,
		[Parameter(Mandatory)] [String]$STIG,
		[Parameter(Mandatory)] [String]$MSFTBaseline,
		# Not Mandatory, and defaults to off: an older template that does not pass this
		# should build a lab without a certificate authority, not fail outright.
		[String]$InstallCA = 'false',
		# Not Mandatory: a plan or template written before install media could be redirected must
		# still deploy, taking every installer from the public internet exactly as it always has.
		[String]$InstallMediaLocation = '',
		[String]$InstallMediaFallback = 'false',
		[Parameter(Mandatory)] [String]$SQLName,
		[Parameter(Mandatory)] [String]$SQLAlias,
		[Parameter(Mandatory)] [String]$DCName,
		[Parameter(Mandatory)] [String]$DPMPName,
		[Parameter(Mandatory)] [String]$PSName,
		[Parameter(Mandatory)] [String]$DNSIPAddress,
		[Parameter(Mandatory)] [String]$SharePointVersion,
		[Parameter(Mandatory)] [System.Management.Automation.PSCredential]$Admincreds,
		[Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SqlSvcCreds,
		[Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSetupCreds,
		[Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPFarmCreds,
		[Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSvcCreds,
		[Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPAppPoolCreds,
		[Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPPassphraseCreds,
		[Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperUserCreds,
		[Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperReaderCreds
	)
	Set-ExecutionPolicy -ExecutionPolicy Bypass -Force
	Import-DscResource -ModuleName TemplateHelpDSC,ActiveDirectoryDsc,ActiveDirectoryCSDsc

	$LogFolder = "TempLog"
	$LogPath = "c:\$LogFolder"
	$DName = $DomainName.Split(".")[0]

	[System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

	Node localhost
	{
	    # Tells every installer script on this machine where to get its media. Written even when
	    # no location was given, so the scripts can always read one answer from one place rather
	    # than each inventing its own default.
	    File InstallMediaSetting
	    {
	        DestinationPath = 'C:\InstallMedia.txt'
	        Contents        = "Location=$InstallMediaLocation`r`nFallback=$InstallMediaFallback`r`n"
	        Type            = 'File'
	        Ensure          = 'Present'
	    }

		# Joining the domain reboots this machine, so the LCM has to be allowed to restart it
		# and pick the configuration back up afterwards.
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
			RebootNodeIfNeeded = $true
		}

		SetCustomPagingFile PagingSettings
		{
			Drive       = 'C:'
			InitialSize = '8192'
			MaximumSize = '8192'
		}

		SetDNS DnsServerAddress
		{
			DNSIPAddress = $DNSIPAddress
			Ensure = "Present"
			DependsOn = "[SetCustomPagingFile]PagingSettings"
		}

		WaitForADDomain WaitForDomain
		{
			DomainName  = $DomainName
			WaitTimeout = 900
			DependsOn = "[SetDNS]DnsServerAddress"
		}

		JoinDomain JoinDomain
		{
			DomainName = $DomainName
			Credential = $DomainCreds
			DependsOn = "[WaitForADDomain]WaitForDomain"
		}

		# AdcsCertificationAuthority configures the role, it does not install it, so the
		# feature has to be present first.
		WindowsFeature ADCS
		{
			Name = "ADCS-Cert-Authority"
			Ensure = "Present"
			IncludeAllSubFeature = $true
			DependsOn = "[JoinDomain]JoinDomain"
		}

		WindowsFeature ADCSTools
		{
			Name = "RSAT-ADCS-Mgmt"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]ADCS"
		}

		# An enterprise CA writes into the configuration naming context, so this needs
		# Enterprise Admins. The machine account is not enough on a member server, which is
		# why the credential is passed explicitly instead of relying on SYSTEM.
		AdcsCertificationAuthority CertificateAuthority
		{
			IsSingleInstance   = 'Yes'
			Ensure             = 'Present'
			CAType             = 'EnterpriseRootCA'
			Credential         = $DomainCreds
			CryptoProviderName = 'RSA#Microsoft Software Key Storage Provider'
			KeyLength          = 2048
			HashAlgorithmName  = 'SHA256'
			DependsOn          = "[WindowsFeature]ADCSTools"
		}
	}
}
