Param($STIG)

If($STIG -eq $True){
Import-Module .\wmifilter.psm1

$ADMXFOLDER = "C:\Windows\SYSVOL\domain\Policies\PolicyDefinitions"
$ADMLFOLDER = "C:\Windows\SYSVOL\domain\Policies\PolicyDefinitions\en-US"

$CyberURL = Invoke-WebRequest -Uri https://public.cyber.mil/stigs/gpo/ -UseBasicParsing

$DLLInk = $CyberURL.Links | Where -Property href -Like "*STIG*.ZIP"

Invoke-WebRequest -Uri $DLLInk.href -OutFile DoDSTIGs.zip -UseBasicParsing

Expand-Archive -Path .\DoDSTIGs.zip -DestinationPath C:\Packages\DODSTIGS\ -Force

$GPOPath = Get-ChildItem -Path C:\Packages\DODSTIGS\* -Directory -Recurse -Include '{*}'

$STIGFILES = Get-ChildItem -Path C:\Packages\DODSTIGS\ -Recurse
$ADMX = $STIGFILES | Where -Property Name -like "*.admx"
$ADML = $STIGFILES | Where -Property Name -like "*.adml"

New-Item -Path "C:\Windows\SYSVOL\domain\Policies" -Name "PolicyDefinitions" -ItemType Directory -Force
New-Item -Path "C:\Windows\SYSVOL\domain\Policies\PolicyDefinitions" -Name "en-US" -ItemType Directory -Force

foreach ($ADMXS in $ADMX){
Copy-Item -Path $ADMXS.FullName -Destination $ADMXFOLDER -Force
}

foreach ($ADMLS in $ADML){
Copy-Item -Path $ADMLS.FullName -Destination $ADMLFOLDER -Force
}

foreach ($GPOPaths in $GPOPath){
[xml]$xml = Get-Content -Path $($GPOPaths.FullName + '\bkupinfo.xml')
Import-GPO -Path $GPOPaths.parent.FullName -CreateIfNeeded -BackupId $xml.BackupInst.ID.'#cdata-section' -TargetName $xml.BackupInst.GPODisplayName.'#cdata-section'
}

New-ADOrganizationalUnit -Name "Servers"
New-ADOrganizationalUnit -Name "Workstations"

New-GPWmiFilter -Name "Windows Server 2019 Member Server" -Expression 'SELECT Version,ProductType FROM Win32_OperatingSystem WHERE Version LIKE \"10.0.17763\" AND ProductType = \"3\"'
New-GPWmiFilter -Name "Windows Server 2019 Domain Controller" -Expression 'SELECT Version,ProductType FROM Win32_OperatingSystem WHERE Version LIKE \"10.0.17763\" AND ProductType = \"2\"'
New-GPWmiFilter -Name "Windows Server 2016 Member Server" -Expression 'SELECT Version,ProductType FROM Win32_OperatingSystem WHERE Version LIKE \"10.0.14393\" AND ProductType = \"3\"'
New-GPWmiFilter -Name "Windows Server 2016 Domain Controller" -Expression 'SELECT Version,ProductType FROM Win32_OperatingSystem WHERE Version LIKE \"10.0.14393\" AND ProductType = \"2\"'

}
