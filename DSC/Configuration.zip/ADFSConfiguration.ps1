﻿Configuration configuration
{
    Param
    (
	[Int]$RetryCount = 20,
	[Int]$RetryIntervalSec = 120,
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [string]$FedServiceDisplayName,
        [string]$FedServiceName,
        [string]$AdfsSrvActName,
        [String]$STIG,
	[string]$DCNameFQDN,
        [String]$DCName,
        [Parameter(Mandatory)]
        [String]$DPMPName,
        [Parameter(Mandatory)]
        [String]$PSName,
        [Parameter(Mandatory)]
        [String]$DNSIPAddress,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    )

    Import-DscResource -ModuleName xComputerManagement,xCertificate,CertificateDsc,xPSDesiredStateConfiguration,xActiveDirectory,PSDesiredStateConfiguration,cADFS,TemplateHelpDSC

    $DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $adfsCred   = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdfsSrvActName)", $Admincreds.Password)
    
    node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        SetCustomPagingFile PagingSettings
        {
            Drive       = 'C:'
            InitialSize = '8192'
            MaximumSize = '8192'
        }

        SetDNS DnsServerAddress
        {
            DNSIPAddress = $DNSIPAddress
            Ensure = "Present"
            DependsOn = "[SetCustomPagingFile]PagingSettings"
        }
        WaitForDomainReady WaitForDomain
        {
            Ensure = "Present"
            DCName = $DCName
            DependsOn = "[SetDNS]DnsServerAddress"
        }

        JoinDomain JoinDomain
        {
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[WaitForDomainReady]WaitForDomain"
        }

        WindowsFeature RSAT
        {
        Name = 'RSAT'
        Ensure = 'Present'
	IncludeAllSubFeature = $true
        }


        xADUser AdfsSrv
        {
            DomainName = $DomainName
            UserName = $AdfsSrvActName
            Password = $adfsCred 
            Ensure = 'Present'
            Enabled = $true
            DomainAdministratorCredential = $domainCreds
            DependsOn = '[JoinDomain]JoinDomain','[WindowsFeature]RSAT'
        }
        CertReq ADFSSite
        {
            CARootName          = $DomainName
            CAServerFQDN        = $DCNameFQDN
            Subject             = "$FedServiceName"
            KeyLength           = '2048'
            Exportable          = $true
            ProviderName        = '"Microsoft RSA SChannel Cryptographic Provider"'
            OID                 = '1.3.6.1.5.5.7.3.1'
            KeyUsage            = '0xa0'
            CertificateTemplate = 'WebServer'
            AutoRenew           = $true
            FriendlyName        = "$FedServiceName adfssite"
            Credential          = $DomainCreds
	    DependsOn = '[JoinDomain]JoinDomain'
        }
        CertReq ADFSSigningCert
        {
            CARootName                = $DomainName
            CAServerFQDN              = $DCNameFQDN
            Subject                   = "$FedServiceName.Signing"
            FriendlyName              = "$FedServiceName Signing"
            KeyLength                 = '2048'
            Exportable                = $true
            ProviderName              = '"Microsoft RSA SChannel Cryptographic Provider"'
            OID                       = '1.3.6.1.5.5.7.3.1'
            KeyUsage                  = '0xa0'
            CertificateTemplate       = 'WebServer'
            AutoRenew                 = $true
            Credential                = $DomainCreds
            DependsOn = '[JoinDomain]JoinDomain'
        }
        CertReq ADFSDecryptionCert
        {
            CARootName                = $DomainName
            CAServerFQDN              = $DCNameFQDN
            Subject                   = "$FedServiceName.Decryption"
            FriendlyName              = "$FedServiceName Decryption"
            KeyLength                 = '2048'
            Exportable                = $true
            ProviderName              = '"Microsoft RSA SChannel Cryptographic Provider"'
            OID                       = '1.3.6.1.5.5.7.3.1'
            KeyUsage                  = '0xa0'
            CertificateTemplate       = 'WebServer'
            AutoRenew                 = $true
            Credential                = $DomainCreds
            DependsOn = '[JoinDomain]JoinDomain'
        }
        WindowsFeature InstallAdfs
        {
            Name   = 'ADFS-Federation'
            Ensure = 'Present'
	    DependsOn = '[JoinDomain]JoinDomain'            
        }        

        cADFSFarm FristAdfsServer
        {
	    ServiceCredential = $adfsCred
            InstallCredential = $DomainCreds
            DisplayName = $FedServiceDisplayName
            ServiceName = $FedServiceName
            CertificateName = "$FedServiceName"
            SigningCertificateName = "$FedServiceName.Signing"
            DecryptionCertificateName = "$FedServiceName.Decryption"
            Ensure= 'Present'
            PsDscRunAsCredential = $DomainCreds     
            DependsOn = '[WindowsFeature]InstallAdfs'
        }
        
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        } 
    }
}

