﻿Configuration configuration
{
    Param
    (
	[Int]$RetryCount = 20,
	[Int]$RetryIntervalSec = 120,
        [Parameter(Mandatory)] [String]$DomainName,
        [Parameter(Mandatory)] [string]$FedServiceDisplayName,
        [Parameter(Mandatory)] [string]$FedServiceName,
        [Parameter(Mandatory)] [string]$AdfsSrvActName,
	[Parameter(Mandatory)] [string]$DCNameFQDN,
        [Parameter(Mandatory)] [String]$STIG,
        [Parameter(Mandatory)] [String]$MSFTBaseline,
        [Parameter(Mandatory)] [String]$SQLName,
        [Parameter(Mandatory)] [String]$SQLAlias,
        [Parameter(Mandatory)] [String]$DCName,
        [Parameter(Mandatory)] [String]$DPMPName,
        [Parameter(Mandatory)] [String]$PSName,
        [Parameter(Mandatory)] [String]$DNSIPAddress,
        [Parameter(Mandatory)] [String]$SharePointVersion,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$Admincreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SqlSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSetupCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPFarmCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSvcCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPAppPoolCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPPassphraseCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperUserCreds,
        [Parameter(Mandatory)] [System.Management.Automation.PSCredential]$SPSuperReaderCreds
    )

    Import-DscResource -ModuleName xComputerManagement,ActiveDirectoryDsc,xCertificate,CertificateDsc,xPSDesiredStateConfiguration,xActiveDirectory,PSDesiredStateConfiguration,cADFS,TemplateHelpDSC
    [String] $DomainNetbiosName = $DomainName.Split(".")[0]
    $DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $adfsCred   = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdfsSrvActName)", $Admincreds.Password)
    
    node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        SetCustomPagingFile PagingSettings
        {
            Drive       = 'C:'
            InitialSize = '8192'
            MaximumSize = '8192'
        }

        SetDNS DnsServerAddress
        {
            DNSIPAddress = $DNSIPAddress
            Ensure = "Present"
            DependsOn = "[SetCustomPagingFile]PagingSettings"
        }

        WaitForADDomain WaitForDomain
        {
            DomainName  = $DomainName
            WaitTimeout = 900
        }

        JoinDomain JoinDomain
        {
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[WaitForADDomain]WaitForDomain"
        }

        WindowsFeature RSAT
        {
        Name = 'RSAT'
        Ensure = 'Present'
	IncludeAllSubFeature = $true
        }


        xADUser AdfsSrv
        {
            DomainName = $DomainName
            UserName = $AdfsSrvActName
            Password = $adfsCred 
            Ensure = 'Present'
            Enabled = $true
            DomainAdministratorCredential = $domainCreds
            DependsOn = '[JoinDomain]JoinDomain','[WindowsFeature]RSAT'
        }

        WaitForCertificateServices RootCA
        {
            CARootName   	 = "$DomainNetbiosName-$DCName-CA"
            CAServerFQDN 	 = $DCNameFQDN
	    RetryIntervalSeconds = '60'
	    DependsOn 		 = '[JoinDomain]JoinDomain'
        }

        # Update GPO to ensure the root certificate of the CA is present in "cert:\LocalMachine\Root\" before issuing a certificate request, otherwise request would fail
        xScript UpdateGPOToTrustRootCACert
        {
            SetScript =
            {
                gpupdate.exe /force
            }
            GetScript            = { }
            TestScript           = { return $false } # If the TestScript returns $false, DSC executes the SetScript to bring the node back to the desired state
            DependsOn            = '[WaitForCertificateServices]RootCA'
            PsDscRunAsCredential = $DomainCreds
        }

        CertReq ADFSSite
        {
            CARootName          = "$DomainNetbiosName-$DCName-CA"
            CAServerFQDN        = $DCNameFQDN
            Subject             = "$FedServiceName"
            KeyLength           = '2048'
            Exportable          = $true
            ProviderName        = '"Microsoft RSA SChannel Cryptographic Provider"'
            OID                 = '1.3.6.1.5.5.7.3.1'
            KeyUsage            = '0xa0'
            CertificateTemplate = 'WebServer'
            AutoRenew           = $true
            FriendlyName        = "$FedServiceName adfssite"
            Credential          = $DomainCreds
	    DependsOn 		= '[xScript]UpdateGPOToTrustRootCACert','[WaitForCertificateServices]RootCA'
        }
        CertReq ADFSSigningCert
        {
            CARootName                = "$DomainNetbiosName-$DCName-CA"
            CAServerFQDN              = $DCNameFQDN
            Subject                   = "$FedServiceName.Signing"
            FriendlyName              = "$FedServiceName Signing"
            KeyLength                 = '2048'
            Exportable                = $true
            ProviderName              = '"Microsoft RSA SChannel Cryptographic Provider"'
            OID                       = '1.3.6.1.5.5.7.3.1'
            KeyUsage                  = '0xa0'
            CertificateTemplate       = 'WebServer'
            AutoRenew                 = $true
            Credential                = $DomainCreds
            DependsOn 		      = '[xScript]UpdateGPOToTrustRootCACert','[WaitForCertificateServices]RootCA'
        }
        CertReq ADFSDecryptionCert
        {
            CARootName                = "$DomainNetbiosName-$DCName-CA"
            CAServerFQDN              = $DCNameFQDN
            Subject                   = "$FedServiceName.Decryption"
            FriendlyName              = "$FedServiceName Decryption"
            KeyLength                 = '2048'
            Exportable                = $true
            ProviderName              = '"Microsoft RSA SChannel Cryptographic Provider"'
            OID                       = '1.3.6.1.5.5.7.3.1'
            KeyUsage                  = '0xa0'
            CertificateTemplate       = 'WebServer'
            AutoRenew                 = $true
            Credential                = $DomainCreds
            DependsOn		      = '[xScript]UpdateGPOToTrustRootCACert','[WaitForCertificateServices]RootCA'
        }
        WindowsFeature InstallAdfs
        {
            Name   = 'ADFS-Federation'
            Ensure = 'Present'
	    DependsOn = '[JoinDomain]JoinDomain'            
        }        

        cADFSFarm FristAdfsServer
        {
	    ServiceCredential = $adfsCred
            InstallCredential = $DomainCreds
            DisplayName = $FedServiceDisplayName
            ServiceName = $FedServiceName
            CertificateName = "$FedServiceName"
            SigningCertificateName = "$FedServiceName.Signing"
            DecryptionCertificateName = "$FedServiceName.Decryption"
            Ensure= 'Present'
            PsDscRunAsCredential = $DomainCreds     
            DependsOn = '[WindowsFeature]InstallAdfs'
        }
        
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        } 
    }
}

