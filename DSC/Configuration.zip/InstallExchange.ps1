﻿# Resolves every download below against an operator-supplied location when one is set.
. "$PSScriptRoot\InstallMedia.ps1"

$uri = "https://download.microsoft.com/download/ad9b1e53-f28e-4a82-987d-6c88803795b2/ExchangeServerSE-x64.iso"
$UcmaUri = "https://download.microsoft.com/download/2/C/4/2C47A5C1-A1F3-4843-B9FE-84C0032C61EC/UcmaRuntimeSetup.exe"
$destination = "ExchangeInstall"

# Both redistributables are required by the Mailbox role. Only the 2013 one used to be fetched.
$distro2012 = "https://download.microsoft.com/download/1/6/b/16b06f60-3b20-4ff2-b699-5e9b7962f9ae/VSU_4/vcredist_x64.exe"
$distro2013 = "https://download.microsoft.com/download/2/E/6/2E61CFA4-993B-4DD4-91DA-3737CD5CD6E3/vcredist_x64.exe"
$urlRewrite = "https://download.microsoft.com/download/1/2/8/128E2E22-C1B9-44A4-BE2A-5859ED1D4592/rewrite_amd64_en-US.msi"

$logFilePath = "$env:SystemDrive\CSDownload.log"

function Write-Log($message)
{
	"[$(Get-Date -Format HH:mm:ss)] $message" | Tee-Object -FilePath $logFilePath -Append
}

# Function

function DownloadISO {

	# Local file storage location
	$localPath = "$env:SystemDrive"

	# Log file
	$logFileName = "CSDownload.log"
	$logFilePath = "$localPath\$logFileName"

	if(Test-Path $destination) {
		"Destination path exists. Skipping ISO download" | Tee-Object -FilePath $logFilePath -Append
		return
	}

	$destination = Join-Path $env:SystemDrive $destination
	New-Item -Path $destination -ItemType Directory

	$destinationFile = $null
	$result = $false
	# Download ISO
	$retries = 3
	# Stop retrying after download succeeds or all retries attempted
	while(($retries -gt 0) -and ($result -eq $false)) {
		try
		{
			"Downloading ISO from URI: $uri to destination: $destination" | Tee-Object -FilePath $logFilePath -Append
			$isoFileName = [System.IO.Path]::GetFileName($uri)
			$_date = Get-Date -Format hh:mmtt
			$destinationFile = "$destination\$isoFileName"
			$mediaSource = Save-InstallMedia -FileName $isoFileName -DefaultUri $uri -Destination $destinationFile
			"Exchange media came from: $mediaSource" | Tee-Object -FilePath $logFilePath -Append
			$_date = Get-Date -Format hh:mmtt
			if((Test-Path $destinationFile) -eq $true) {
				"Downloading ISO file succeeded at $_date" | Tee-Object -FilePath $logFilePath -Append
				$result = $true
			}
			else {
				"Downloading ISO file failed at $_date" | Tee-Object -FilePath $logFilePath -Append
				$result = $false
			}
		} catch [Exception] {
			"Failed to download ISO. Exception: $_" | Tee-Object -FilePath $logFilePath -Append
			$retries--
			if($retries -eq 0) {
				Remove-Item $destination -Force -Confirm:0 -ErrorAction SilentlyContinue
			}
		}
	}

	# Extract ISO
	if($result)
	{
		"Mount the image from $destinationFile" | Tee-Object -FilePath $logFilePath -Append
		$image = Mount-DiskImage -ImagePath $destinationFile -PassThru
		$driveLetter = ($image | Get-Volume).DriveLetter

		"Copy files to destination directory: $destination" | Tee-Object -FilePath $logFilePath -Append
		Robocopy.exe ("{0}:" -f $driveLetter) $destination /E | Out-Null

		"Dismount the image from $destinationFile" | Tee-Object -FilePath $logFilePath -Append
		Dismount-DiskImage -ImagePath $destinationFile

		"Delete the temp file: $destinationFile" | Tee-Object -FilePath $logFilePath -Append
		Remove-Item -Path $destinationFile -Force
	}
	else
	{
		"Failed to download the file after exhaust retry limit" | Tee-Object -FilePath $logFilePath -Append
		Remove-Item $destination -Force -Confirm:0 -ErrorAction SilentlyContinue
		Throw "Failed to download the file after exhaust retry limit"
	}
}

<#
	Runs an installer and waits for it. Every one of these used to be started without -Wait, so
	Exchange setup began while its own prerequisites were still installing - a race that failed
	intermittently and blamed Exchange.

	0 is success and 3010 is "success, reboot required"; anything else is a real failure and is
	worth stopping for, because Exchange setup's own prerequisite check would fail later with a
	much less obvious message.
#>
function Invoke-Installer($path, $arguments, $name)
{
	Write-Log "Installing $name..."

	$process = Start-Process -FilePath $path -ArgumentList $arguments -Wait -PassThru
	if($process.ExitCode -eq 0 -or $process.ExitCode -eq 3010)
	{
		Write-Log "$name installed (exit code $($process.ExitCode))."
		return
	}

	throw "$name failed with exit code $($process.ExitCode)."
}

function Get-Installer($url, $fileName)
{
	$path = Join-Path $env:SystemDrive $fileName
	if(!(Test-Path $path))
	{
		Write-Log "Downloading $fileName..."
		$mediaSource = Save-InstallMedia -FileName $fileName -DefaultUri $url -Destination $path
		Write-Log "  from $mediaSource"
	}

	return $path
}


# Download Exchange and Ucma
DownloadISO


# Install Exchange
$installfolder = Join-Path $env:SystemDrive $destination

# UCMA ships on the Exchange media in \UCMARedist, so prefer the copy that is already on disk and
# is guaranteed to match this build. The download is only a fallback.
$ucmaLocal = Join-Path $installfolder "UCMARedist\Setup.exe"
if(Test-Path $ucmaLocal)
{
	Invoke-Installer $ucmaLocal "-q" "UCMA 4.0 runtime (from the Exchange media)"
}
else
{
	Invoke-Installer (Get-Installer $UcmaUri "UcmaRuntimeSetup.exe") "-q" "UCMA 4.0 runtime"
}

Invoke-Installer (Get-Installer $distro2012 "vcredist2012_x64.exe") "/install /quiet /norestart" "Visual C++ 2012 redistributable"
Invoke-Installer (Get-Installer $distro2013 "vcredist2013_x64.exe") "/install /quiet /norestart" "Visual C++ 2013 redistributable"

$rewritePath = Get-Installer $urlRewrite "rewrite_amd64_en-US.msi"
Invoke-Installer "msiexec.exe" "/i `"$rewritePath`" /quiet /norestart" "IIS URL Rewrite module"

<#
	/IAcceptExchangeServerLicenseTerms was removed in the September 2021 cumulative updates and
	setup now refuses to run without one of the _DiagnosticData switches. OFF is chosen because a
	disconnected lab cannot send diagnostic data anyway.

	/InstallWindowsComponents lets setup add the IIS and .NET features itself, which is the
	documented alternative to a hand-maintained Install-WindowsFeature list - and that list changed
	between Exchange 2016 and SE (MSMQ is no longer required).
#>
$ExchangeInstall = "$installfolder\setup.exe"
Write-Log "Starting Exchange setup..."
$setup = Start-Process $ExchangeInstall -ArgumentList "/Mode:Install /Role:Mailbox /OrganizationName:ExchOrg /TargetDir:C:\Exchange /IAcceptExchangeServerLicenseTerms_DiagnosticDataOFF /InstallWindowsComponents" -Wait -PassThru

if($setup.ExitCode -eq 0 -or $setup.ExitCode -eq 3010)
{
	Write-Log "Exchange setup finished with exit code $($setup.ExitCode)."
}
else
{
	throw "Exchange setup failed with exit code $($setup.ExitCode). See C:\ExchangeSetupLogs\ExchangeSetup.log."
}
